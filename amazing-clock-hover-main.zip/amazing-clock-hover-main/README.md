## Amazing Clock
📜 Feito em HTML, CSS e JavaScript.

![image](https://user-images.githubusercontent.com/79935555/187453528-ca12d3e8-277e-4cec-b187-acaee0539f77.png)


### ⏰ Sobre
Relogio com efeito Hover e reflexo, feito usando HTML, CSS e JS, código comentado, espero que gostem, divirta-se :D

[Acesse](https://luuan11.github.io/amazing-clock-hover/clock.html)

### ✨ Tecnologias Usadas 
<code><img height="50" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="50" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="50" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>

---

Made with 💜 by [Luan Fernando](https://www.linkedin.com/in/luan-fernando/).
